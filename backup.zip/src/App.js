import React, { useState, useEffect } from 'react';
import { Route, BrowserRouter, Switch, Router } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import MovieList from './components/MovieList';
import MovieListHeader from './components/MovieListHeader';
import MovieDetail from './components/MovieDetail';
import Search from './components/Search';
import axios from 'axios';

function App() {
  const [movies, setMovies] = useState([]);
  const [searchValue, setSearchValue] = useState('');

  const getMovieRequest = async (searchValue) => {
    axios.get(`http://www.omdbapi.com/?apikey=faf7e5bb&s=${searchValue}&page=1`)
      .then(res => {
        if (res.data.Search) {
          setMovies(res.data.Search);
        }
    });
  };

  useEffect(() => {
    getMovieRequest(searchValue);
  }, [searchValue]);

  return (
    <BrowserRouter>
    <div className="App-Header">
        <div className='container-fluid movie-app'>
          <div className='row d-flex align-items-center mt-4 mb-4'>
            <MovieListHeader heading='Movie List' />
            <Search heading='Search' searchValue={searchValue} setSearchValue={setSearchValue} />
          </div>
          <div className='row'>
            <MovieList
              movies={movies}
            />
          </div>
        </div>
    </div>
   
    <Switch>
      <Route path='/movie/:movie_id' component={MovieDetail} />
    </Switch>
    </BrowserRouter>
  );
}

export default App;
