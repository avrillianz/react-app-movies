import React, { Component } from 'react'
import { connect } from 'react-redux'
import axios from 'axios'

class MovieDetail extends Component {
    state = {
        movie: null
    }

    componentDidMount(){
        let id = this.props.match.params.title_id;
        axios.get(`http://www.omdbapi.com/?apikey=faf7e5bb&i=${id}&page=1`)
            .then(res => {
                alert(res);
                if (res.data) {
                    this.state.movie(res.data);
                }
        });
    }
    render() {
        const movie = this.props.movie ? (
            <div className="post">
                <h4 className="center">{this.props.movie.title}</h4>
                <p>{this.props.movie.body}</p>
            </div>
        ) : (
                <div className="center">Loading Movie Detail...</div>
            );

        return (
            <div className="container">
                {movie}
            </div>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    let id = ownProps.match.params.movie_id;

    return {
        movie: state.movie.find(movie => movie.id === id)
    }
}

export default connect(mapStateToProps)(MovieDetail)
