import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import axios from 'axios';
import { connect } from 'react-redux';

const MovieList = (props) => {
    const {
        buttonLabel,
        className
    } = props;

    const [modal, setModal] = useState(false);
    const [source, setSource] = useState('');

    const toggle = (event) => {
        setSource(event.target.currentSrc);
        setModal(!modal);
    }
    const mystyle = {
        textAlign: 'center'
    };

    return (
        <>
            {props.movies.map((movie, index) => (
                <div className='image-container d-flex justify-content-start m-3'>
                    <img src={movie.Poster} onClick={toggle} alt='movie'></img>
                    <div
                        className='overlay d-flex align-items-center justify-content-center'
                    >
                        <Link to={'/movie/' + movie.imdbID}>
                            <Button color="primary"><span className='mr-2'>Detail Movie</span></Button>
                        </Link>
                    </div>
                </div>
            ))}
            <Modal isOpen={modal} toggle={toggle} className={className}>
                <ModalHeader toggle={toggle}>Poster Detail</ModalHeader>
                <ModalBody>
                    <div style={mystyle}>
                        <img src={source} alt='movie'></img>
                    </div>
                </ModalBody>
                <ModalFooter>
                    <Button color="secondary" onClick={toggle}>Cancel</Button>
                </ModalFooter>
            </Modal>
        </>
    );
};

export default MovieList;
